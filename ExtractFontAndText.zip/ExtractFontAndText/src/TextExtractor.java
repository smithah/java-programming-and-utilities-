
import com.snowtide.PDF;
import com.snowtide.pdf.Document;
import com.snowtide.pdf.OutputTarget;
import org.apache.poi.hssf.extractor.ExcelExtractor;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.xddf.usermodel.text.XDDFTextParagraph;
import org.apache.poi.xssf.extractor.XSSFExcelExtractor;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFConnectorShape;
import org.apache.poi.xslf.usermodel.XSLFNotes;
import org.apache.poi.xslf.usermodel.XSLFPictureShape;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFTextParagraph;
import org.apache.poi.xslf.usermodel.XSLFTextRun;
import org.apache.poi.xslf.usermodel.XSLFTextShape;


import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.rtf.RTFEditorKit;


import java.awt.Dimension;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import json.pptx.*;
import extractor.util.*;
import org.apache.poi.sl.*;
import org.apache.poi.sl.draw.DrawPaint;
import org.apache.poi.sl.usermodel.ColorStyle;
import org.apache.poi.sl.usermodel.PaintStyle;
import org.apache.poi.sl.usermodel.PaintStyle.SolidPaint;
import org.apache.poi.sl.usermodel.TextParagraph;

import java.awt.Color;
import java.awt.geom.Rectangle2D;

import json.pptx.Datum;





/**
 * Extracts text only from Word, Excel, RTF , PPTX and PDF files. 
 *
 */

@SuppressWarnings("unused")
public class TextExtractor {
    private static Logger log = Logger.getLogger(TextExtractor.class.getName());

    public enum Type {PDF, XLSX, XLS, DOC, DOCX, RTF,PPTX}

    public String parse(String reference, InputStream is) {
        return parse(referenceToType(reference), is);
    }

    private Type referenceToType(String reference) {
        Type type = null;
        String referenceInLowerCase = reference.toLowerCase();

        if (referenceInLowerCase.endsWith(".pdf") || referenceInLowerCase.equals("application/pdf")) {
            type = Type.PDF;
        } else if (referenceInLowerCase.endsWith(".doc") || referenceInLowerCase.equals("application/msword")) {
            type = Type.DOC;
        } else if (referenceInLowerCase.endsWith(".docx") || referenceInLowerCase.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
            type = Type.DOCX;
        } else if (referenceInLowerCase.endsWith(".rtf") || referenceInLowerCase.equals("application/rtf")) {
            type = Type.RTF;
        } else if (referenceInLowerCase.endsWith(".xls") || referenceInLowerCase.equals("application/vnd.ms-excel")) {
            type = Type.XLS;
        } else if (referenceInLowerCase.endsWith(".xlsx") || referenceInLowerCase.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
            type = Type.XLSX;
        }else if (referenceInLowerCase.endsWith(".pptx") || referenceInLowerCase.equals("application/vnd.openxmlformats-officedocument.presentationml.presentation")) {
            type = Type.PPTX;
        }

        if (type == null)
            throw new RuntimeException("There's no a valid reference to detect the type of the input stream.");

        return type;
    }

    public String parse(Type type, InputStream is) {
        String result = "";

        try {
            if (type.equals(Type.PDF)) {
                result = pdf2text(is);
            } else if (type.equals(Type.DOC)) {
                result = doc2text(is);
            } else if (type.equals(Type.DOCX)) {
                result = docx2text(is);
            } else if (type.equals(Type.RTF)) {
                result = rtf2text(is);
            } else if (type.equals(Type.XLS)) {
                result = xls2text(is);
            } else if (type.equals(Type.XLSX)) {
                result = xlsx2text(is);
            }else if (type.equals(Type.PPTX)) {
                result = pptx2text(is);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return result;
    }

    public String pdf2text(InputStream is) {
        StringBuilder parsedText = new StringBuilder(1024);

        try {
            Document pdf = PDF.open(is, "");
            pdf.pipe(new OutputTarget(parsedText));
            pdf.close();
        } catch (Exception e) {
            log.log(Level.WARNING, "An exception has occurred while parsing the PDF Document.", e);
        }

        log.info("Done");
        return parsedText.toString();
    }

    public String xls2text(InputStream is) throws IOException {
        ExcelExtractor wd = new ExcelExtractor(new HSSFWorkbook(is));
        String text = wd.getText();
        wd.close();
        return text;
    }

    public String xlsx2text(InputStream is) throws Exception {
        XSSFWorkbook wb = new XSSFWorkbook(is);
        XSSFExcelExtractor we = new XSSFExcelExtractor(wb);
        String text = we.getText();
        we.close();
        return text;
    }

    public String doc2text(InputStream is) throws IOException {
        WordExtractor wd = new WordExtractor(is);
        String text = wd.getText();
        wd.close();
        return text;
    }

    public String docx2text(InputStream is) throws IOException {
        XWPFDocument doc = new XWPFDocument(is);
        XWPFWordExtractor we = new XWPFWordExtractor(doc);
        String text = we.getText();
        we.close();
        return text;
    }

    public String rtf2text(InputStream is) throws Exception {
        DefaultStyledDocument styledDoc = new DefaultStyledDocument();
        new RTFEditorKit().read(is, styledDoc, 0);
        return styledDoc.getText(0, styledDoc.getLength());
    }
    
    public String pptx2text(InputStream is) throws IOException {
    	String text = null;
    	JSONObj ob = new JSONObj();
    	
    	Datum dn = new Datum();
    	DataPptx pd = new DataPptx();
    	PptxJsonObject jsonObj = new PptxJsonObject();
    	 ArrayList<Ppptxjson> pjson = new ArrayList<Ppptxjson>();
    	
    	 
try {
			
			XMLSlideShow ppt = new XMLSlideShow(is);
				 for (XSLFSlide slide: ppt.getSlides()) {
					 Ppptxjson p = new Ppptxjson();
					 pd = new DataPptx();
					 Dimension dim = ppt.getPageSize();
					 ArrayList<PptData> data = new ArrayList<PptData>();
					 List<Datum> dataum = new ArrayList<Datum>();
	        			p.setHeight(dim.height);
	        			pd.setHeight(dim.height);
	        			pd.setWidth(dim.width);
			        	p.setWidth(dim.width);
			        	p.setSlidenum(slide.getSlideNumber());
			        	System.out.println("Starting slide...");
			        	ob.setSlidenum(slide.getSlideNumber() -1 );
			        	System.out.println("Slide Number: " + slide.getSlideNumber());
					 List<XSLFShape> shapes = slide.getShapes();       	
			        	
			        	for (XSLFShape shape: shapes) {			        		
			        					        		
			        		if (shape instanceof XSLFTextShape) {			        			
			        	        XSLFTextShape textShape = (XSLFTextShape)shape;
			        	        String font_style = "";
			        	        text = textShape.getText();
			        	        
			        	        
			        	        PptData d = new PptData();
			        	        dn = new Datum();
			        	        dn.setOriginalText(text);
			        	        d.setOriginalText(text);
			        	       // System.out.println("Text: " + text);
			        	        //System.out.println("paragraph :: run color is::    " + textShape.getTextHeight());
			        	        
			        	        if(textShape.getFillColor() != null) {
			        	        String hex = Integer.toHexString(textShape.getFillColor().getRGB() & 0xffffff);
			        	        if (hex.length() < 6) {
			        	            hex = "0" + hex;
			        	        }
			        	        hex = "#" + hex;
			        	        d.setFontColorHex(hex);
			        	        dn.setFontColorHex(hex);
			        	       
			        	        if (hex.startsWith("#")) {
			        	        	d.setFontColor(Integer.parseInt(hex.substring(1), 16));
			        	        	dn.setFontColor(Integer.parseInt(hex.substring(1), 16));
			        	           
			        	        }

			        	     
				        	       
			        	        
			        	        }
			        	        
			        	        Rectangle2D rcord = shape.getAnchor();
			        	        d.setTop((double) rcord.getMinX());
			        	        d.setEndTop((double) rcord.getMaxX());
			        	        d.setLeft((double) rcord.getMinY()); 
			        	        d.setEndLeft((double) rcord.getMaxY());
	        		        	d.setFontStyle(font_style);
	        		        	
	        		        	dn.setTop((double) rcord.getMinX());
			        	        dn.setEndTop((double) rcord.getMaxX());
			        	        dn.setLeft((double) rcord.getMinY()); 
			        	        dn.setEndLeft((double) rcord.getMaxY());
	        		        	dn.setFontStyle(font_style);
			        	        HashMap map = new HashMap();
			        	        List<XSLFTextParagraph> textParagraphs = textShape.getTextParagraphs();
			        	        if(textParagraphs != null) {			        	        	
			        		    for (int i = 0; i < textParagraphs.size(); i++) {
			        		        for (XSLFTextRun run : textParagraphs.get(i).getTextRuns()) { 
			        		        	if(map.containsValue(run.getParagraph().getText())) {
			        		        		continue;
			        		        	}
			        		        	
			        		        	
			        		        	
			        		        				        		        	
			        		        	map.put(run.getParagraph().getText(), run.getParagraph().getText());
			        		        	//d.setLeft((double)run.getParagraph().getDefaultMasterStyle().xgetMarL().getIntValue());
			        		        	//d.setEndLeft((double)run.getParagraph().getDefaultMasterStyle().xgetMarR().getIntValue());
			        		        	//d.setTop(run.getParagraph().getSpaceBefore());
			        		        	//d.setEndTop(run.getParagraph().getSpaceAfter());
			        		        	d = new PptData();
			        		        	dn = new Datum();
			        		        	 rcord = shape.getAnchor();
			        		        	 d.setTop((double) rcord.getMinX());
						        	        d.setEndTop((double) rcord.getMaxX());
						        	        d.setLeft((double) rcord.getMinY()); 
						        	        d.setEndLeft((double) rcord.getMaxY());
						        	        
						        	        dn.setTop((double) rcord.getMinX());
						        	        dn.setEndTop((double) rcord.getMaxX());
						        	        dn.setLeft((double) rcord.getMinY()); 
						        	        dn.setEndLeft((double) rcord.getMaxY());
			        		        	font_style = "";
			        		        	d.setOriginalText(run.getParagraph().getText());
			        		        	dn.setOriginalText(run.getParagraph().getText());
			        		        	//System.out.println("paragraph :: run color is::    " + run.getFontColor());
			        		        	PaintStyle t = run.getFontColor();
			        		        	ColorStyle cs = ((SolidPaint)t).getSolidColor();
			        		        	Color actColor = (Color) cs.getColor();
			        		        	String hexValue = "#"+Integer.toHexString(actColor.getRGB()).substring(2);
			        		        	if (hexValue.startsWith("#")) {
					        	        	d.setFontColor(Integer.parseInt(hexValue.substring(1), 16));
					        	        	dn.setFontColor(Integer.parseInt(hexValue.substring(1), 16));
					        	           
					        	        }
			        		        	
			        		        	
			        		        	d.setFontColorHex(hexValue);
			        		        	dn.setFontColorHex(hexValue);
			        		        	if(run.isBold()) {
			        		        		font_style += "Bold ";			        		        		
			        		        	} if(run.isItalic()) {
			        		        		font_style += "Italic ";
			        		        	} if (run.isUnderlined()) {
			        		        		font_style += "Underlined";
			        		        	} if(run.isStrikethrough()) {
			        		        		font_style += "Strikethrough";
			        		        	} if(run.isSubscript()) {
			        		        		font_style += "Subscript";
			        		        	} if(run.isSuperscript()) {
			        		        		font_style += "Superscript";
			        		        	}
			        		        	
			        		        	d.setFontStyle(font_style);
			        		        	dn.setFontStyle(font_style);
			        		        	//d.setFontColor(String.valueOf(actColor));
			        		        	//d.setFontColorHex("#"+Integer.toHexString(actColor.getRGB()).substring(2));
					                    //System.out.println("paragraph :: run font-size is::    " + run.getFontSize()); //It always return null; why?
			        		        	d.setFontFamily(run.getFontFamily());
			        		        	d.setFontSize(run.getFontSize());
			        		        	dn.setFontFamily(run.getFontFamily());
			        		        	dn.setFontSize(run.getFontSize());			        		        	
			        		        	
			        		        	dataum.add(dn);
			        		        		data.add(d);
			        		        
			        		        
			        		        	
			        		            
			        		        	 	
					                           		    
			        	        }       	        		        		
					        	      					        		
			        		}			        		    
			        	
			        	}     
			        	        
			        	        dataum.add(dn);
	        		        		data.add(d);
	        		        		pd.setData(dataum);
	        		        		 ob.setAdditionalProperty(String.valueOf(ob.getSlidenum()), pd);
	        		        
			        		}	
			        		
			        		
			       }
			        	
			        	for (int i = 0; i < data.size(); i++) {
			                for (int j = i + 1; j < data.size(); j++) {
			                    if (data.get(i).equals(data.get(j))) {
			                    	data.remove(j);
			                        j--;
			                    }
			                }
			            }
			        	 // pd.setData(dataum);
			        	  p.setData(data);
			        	  pjson.add(p);
			        	  //ob.setAdditionalProperty(String.valueOf(ob.getSlidenum()), pd);
			        	 
			        	
						 System.out.println("*****************************************************************************************");
				 }
				
				 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//jsonObj.setPptxJSON(pjson);
     
	//ExtractorUtility.objectToJsonPptx(jsonObj);
	try {
		ExtractorUtility.objectToJsonPptx(ob);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
return text;
    }
    
    
}