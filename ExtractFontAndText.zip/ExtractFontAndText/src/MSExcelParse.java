import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xslf.extractor.XSLFExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFStyle;
import org.apache.poi.xwpf.usermodel.XWPFStyles;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.microsoft.ooxml.OOXMLParser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.SAXException;
import java.awt.Font;
import java.util.List;






public class MSExcelParse {
	
	
   public static void main(final String[] args) throws IOException, TikaException, SAXException {
	   FileInputStream fis = new FileInputStream("SBI.pptx");
	 
      //detecting the file type
      BodyContentHandler handler = new BodyContentHandler();
      Metadata metadata = new Metadata();
      FileInputStream inputstream = new FileInputStream(new File("example_msExcel.xlsx"));
      XWPFDocument docx = new XWPFDocument(fis);
     
      XWPFStyles styles = docx.getStyles();
      List<XWPFParagraph> paragraphList =  docx.getParagraphs();
      for (int i = 0; i < paragraphList.size(); i++) {
          System.out.println("paragraph " + i + " is::    " + paragraphList.get(i).getText());
          for (XWPFRun run : paragraphList.get(i).getRuns()) {
              System.out.println("paragraph :: run text is::    " + run.text());
              System.out.println("paragraph :: run color is::    " + run.getColor());
              System.out.println("paragraph :: run font-famyly is::    " + run.getFontFamily()); //It always return null; why?
              System.out.println("paragraph :: run font-name is::    " + run.getFontName()); //It always return null; why?
              System.out.println("paragraph :: run text position is::    " + run.getTextPosition()); //It always return -1; why?
              System.out.println("paragraph :: run IsBold::    " + run.isBold());
              System.out.println("paragraph :: run IsItalic::    " + run.isItalic());

          }}
      
            
      for (int i = 0; i < paragraphList.size(); i++) {
          System.out.println("paragraph " + i + " styleID  is::    " + paragraphList.get(i).getStyleID());
          if (paragraphList.get(i).getStyleID() != null) {
              String styleid = paragraphList.get(i).getStyleID();
              XWPFStyle style = styles.getStyle(styleid);
              if (style != null) {
                  System.out.println("style name is::    " + style.getName());
                  if (style.getName().startsWith("heading")) {
                      System.out.println("This part of text is heading!!");
                  }
              }

          }
      }
      ParseContext pcontext = new ParseContext();
      
      //OOXml parser
      OOXMLParser  msofficeparser = new OOXMLParser (); 
      try {
    	  
    	 			msofficeparser.parse(inputstream, handler, metadata,pcontext);
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (TikaException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      
      System.out.println("Contents of the document:" + handler.toString());
      System.out.println("Font of the Text : " + Font.getFont(inputstream.toString()));
      System.out.println("Metadata of the document:");
      String[] metadataNames = metadata.names();
      
      for(String name : metadataNames) {
         System.out.println(name + ": " + metadata.get(name));
      }
   }
}