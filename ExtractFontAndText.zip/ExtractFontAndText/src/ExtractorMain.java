import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExtractorMain {
	
	public static void main(String args[]) throws FileNotFoundException {
		
		TextExtractor txt = new TextExtractor();
		String result = txt.parse("SBI.pptx", new FileInputStream("SBI.pptx"));
		System.out.println(result);
	}

}
