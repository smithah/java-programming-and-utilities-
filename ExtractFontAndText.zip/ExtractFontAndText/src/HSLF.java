import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hslf.usermodel.HSLFHyperlink;
import org.apache.poi.hslf.usermodel.HSLFShape;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hslf.usermodel.HSLFSlideShowImpl;
import org.apache.poi.hslf.usermodel.HSLFTextParagraph;
import org.apache.poi.hslf.usermodel.HSLFTextRun;
import org.apache.poi.sl.usermodel.Line;
import org.apache.poi.xddf.usermodel.text.XDDFTextParagraph;
import org.apache.poi.xddf.usermodel.text.XDDFTextRun;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFSlideMaster;
import org.apache.poi.xslf.usermodel.XSLFTextParagraph;
import org.apache.poi.xslf.usermodel.XSLFTextRun;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextParagraph;

import com.microsoft.schemas.office.drawing.x2008.diagram.CTShape;

public class HSLF {
	
	public static void main(String args[]) throws FileNotFoundException, IOException {
		
		
		try {
			
			XMLSlideShow ppt = new XMLSlideShow(new FileInputStream("SBI.pptx"));
				 for (XSLFSlide slide: ppt.getSlides()) {
			        	System.out.println("Starting slide...");
			        	List<XSLFShape> shapes = slide.getShapes();
			        	System.out.println("Slide Number: " + slide.getSlideNumber());
			        	
			        	for (XSLFShape shape: shapes) {
			        		if (shape instanceof XSLFTextShape) {
			        	        XSLFTextShape textShape = (XSLFTextShape)shape;
			        	        String text = textShape.getText();
			        	        System.out.println("Text: " + text);
			        	        System.out.println("paragraph :: run color is::    " + textShape.getTextHeight());
			        	        
			        	        System.out.println("left :: " + textShape.getLeftInset());
			        	        System.out.println("end_left :: " + textShape.getRightInset());
			        	        System.out.println("top :: " + textShape.getTopInset());
			        	        System.out.println("end_top :: " + textShape.getBottomInset());
			        	        
			        	        
			        	        
			        	        System.out.println("paragraph :: run color is::    " + textShape.getFillColor());
			        	        System.out.println("paragraph :: run font-size is::    " + textShape.getFillStyle());
			        	       
			        	        } 
			        	        
			        	       /** List<XDDFTextParagraph> textParagraphs = textShape.getTextBody().getParagraphs();
			        		    for (int i = 0; i < textParagraphs.size(); i++) {
			        		        for (XDDFTextRun run : textParagraphs.get(i).getTextRuns()) {                            
			        		        	System.out.println("paragraph :: run color is::    " + run.getFontColor());
					                    System.out.println("paragraph :: run font-size is::    " + run.getFontSize()); //It always return null; why?
					                    System.out.println("paragraph :: run IsBold::    " + run.isBold());
					                    System.out.println("paragraph :: run IsItalic::    " + run.isItalic());
			        		        }
			        		    }**/
			        	        
			        	        
					        	      
					        	       
					                    
					        	       
					        		
			        		}
			        	}
			        	
			        	
			        	System.out.println("*****************************************************************************************");
			        	 
				    
				    
				    	
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// get slides
		
			 
			
	}

}
